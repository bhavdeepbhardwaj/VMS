<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('title.complaintRegistration'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTENT WRAPPER -->
    <div class="ec-content-wrapper">
        <div class="content">
            <div class="row">
                <div class="col-xl-1 ">
                </div>
                <div class="col-xl-10 col-lg-12">
                    <div class="ec-cat-list card card-default mb-24px">
                        <div class="card-body">

                            <div class="row">
                                <div class="col-xl-6 col-sm-6 p-b-15 lbl-card">
                                    <div class="card card-mini dash-card card-1">
                                        <div class="card-body">
                                            <h2 class="mb-1"><?php echo e($total); ?></h2>
                                            <p>Total Complaint</p>
                                            <span class="mdi mdi-account-card-details"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-sm-6 p-b-15 lbl-card">
                                    <div class="card card-mini dash-card card-3">
                                        <div class="card-body">

                                            <h2 class="mb-1"><?php echo e($solved); ?></h2>
                                            <p>Resolved Complaint</p>
                                            <span class="mdi mdi-account-card-details"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            

                            <h4>Complaint Registration</h4>
                            <hr>
                            <small>Items marked with an asterisk (*) must be filled out.</small><br><br>

                            <div class="col-lg-12">
                                <?php echo $__env->make('component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="ec-vendor-upload-detail">
                                    <form class="row g-3" method="POST" action="<?php echo e(route('complaintRegistration.store')); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>


                                        <div class=" container">
                                            <div class="col-12 col-md-12 col-lg-12">
                                                <div class="row">

                                                    
                                                    <div class="col-md-12 col-lg-12">
                                                        <div class="mb-3">
                                                            <label for="ticketID" hidden class="form-label">Ticket ID
                                                                <span class="required"> *</span></label>
                                                            <input type="hidden" class="form-select1" id="ticketID"
                                                                aria-describedby="ticketIDHelp" name="ticketID"
                                                                value="<?php echo e($ticketID); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-12 col-lg-12">
                                                        <div class="mb-3">
                                                            <label for="status" hidden class="form-label">Status <span
                                                                    class="required"> *</span></label>
                                                            <input type="hidden" class="form-select1" id="status"
                                                                aria-describedby="statusHelp" name="status"
                                                                value="Pending For Review" readonly>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-4 col-lg-4">
                                                        <div class="mb-3">
                                                            <label for="name" class="form-label">Customer Name<span
                                                                    class="required"> *</span></label>
                                                            <input type="text" class="form-select1" id="name"
                                                                aria-describedby="nameHelp" name="name"
                                                                value="<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?>"
                                                                readonly>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-4 col-lg-4">
                                                        <div class="mb-3">
                                                            <label for="email" class="form-label">Customer Email<span
                                                                    class="required"> *</span></label>
                                                            <input type="email" class="form-select1" id="email"
                                                                aria-describedby="emailHelp" name="email"
                                                                value="<?php echo e(Auth::user()->email); ?>" readonly>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-4 col-lg-4">
                                                        <div class="mb-3">
                                                            <label for="phone" class="form-label">Customer Phone<span
                                                                    class="required"> *</span></label>
                                                            <input type="tel"
                                                                class="form-select1 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="phone" aria-describedby="phoneHelp" name="phone"
                                                                value="<?php echo e(Auth::user()->phone); ?>" readonly>
                                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="phoneHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-6 col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="ticketOld" class="form-label">Previous Complaint
                                                                ID<span class="required">(Optional)</span></label>
                                                            <input type="text"
                                                                class="form-select1 <?php $__errorArgs = ['ticketOld'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="ticketOld" aria-describedby="ticketOldHelp"
                                                                name="ticketOld">
                                                            <?php $__errorArgs = ['ticketOld'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="ticketOldHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-6 col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="priority" class="form-label">Priority Code<span
                                                                    class="required">(Optional)</span></label>
                                                            <input type="text"
                                                                class="form-select1 <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="priority" aria-describedby="priorityHelp"
                                                                name="priority">
                                                            <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="priorityHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-6 col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="productPartNo" class="form-label">Notebook
                                                                Model No.<span class="required"> *</span> <small>(
                                                                    Please check the backside of the notebook Example:
                                                                    ABCXYZ1234-XX),</small></label>
                                                            <input type="text"
                                                                class="form-select1 <?php $__errorArgs = ['productPartNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="productPartNo" aria-describedby="productPartNoHelp"
                                                                name="productPartNo">
                                                            <?php $__errorArgs = ['productPartNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text"
                                                                    id="productPartNoHelp" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>



                                                    
                                                    <div class="col-md-6 col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="productSerialNo" class="form-label">Serial
                                                                Number<span class="required"> *</span> <small>(
                                                                    Please check the backside of the notebook Example:
                                                                    ABCXYZ1234XX),</small></label>
                                                            <input type="text"
                                                                class="form-select1 <?php $__errorArgs = ['productSerialNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="productSerialNo"
                                                                aria-describedby="productSerialNoHelp"
                                                                name="productSerialNo">
                                                            <?php $__errorArgs = ['productSerialNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text"
                                                                    id="productSerialNoHelp" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>


                                                    
                                                    

                                                    
                                                    <div class="col-md-4 col-md-4">
                                                        <div class="mb-3">
                                                            <label for="purchaseDate" class="form-label">Purchase
                                                                Date<span class="required"> *</span></label>
                                                            <input type="date"
                                                                class="form-select1 <?php $__errorArgs = ['purchaseDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="dateID" aria-describedby="purchaseDateHelp"
                                                                name="purchaseDate">
                                                            <?php $__errorArgs = ['purchaseDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="purchaseDateHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-4 col-md-4">
                                                        <div class="mb-3">
                                                            <label for="warrantyCheck" class="form-label">Warranty
                                                                Check<span class="required"> *</span></label>
                                                            <select
                                                                class="form-select1 <?php $__errorArgs = ['warrantyCheck'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="warrantyCheck" aria-describedby="warrantyCheckHelp"
                                                                name="warrantyCheck">
                                                                <option value="">------</option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                            <?php $__errorArgs = ['warrantyCheck'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text"
                                                                    id="warrantyCheckHelp" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md- col-md-4">
                                                        <div class="mb-3">
                                                            <label for="channelPurchase" class="form-label">Channel Of
                                                                Purchase<span class="required"> *</span></label>
                                                            <select
                                                                class="form-select1 <?php $__errorArgs = ['channelPurchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="channelPurchase"
                                                                aria-describedby="channelPurchaseHelp"
                                                                name="channelPurchase">
                                                                <option value="">------</option>
                                                                <option value="Online">Online</option>
                                                                <option value="Offline">Offline</option>
                                                            </select>
                                                            <?php $__errorArgs = ['channelPurchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text"
                                                                    id="channelPurchaseHelp" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md- col-md-4">
                                                        <div class="mb-3">
                                                            <label for="countries" class="form-label">Countries<span
                                                                    class="required"> *</span></label>
                                                            <select
                                                                class="form-select1 <?php $__errorArgs = ['countries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="countries" aria-describedby="countriesHelp"
                                                                name="countries">
                                                                <option value="">------</option>
                                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($data->id); ?>">
                                                                        <?php echo e($data->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['countries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="countriesHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    

                                                    <div class="col-md- col-md-4">
                                                        <div class="mb-3">
                                                            <label for="state" class="form-label">State<span
                                                                    class="required"> *</span></label>
                                                            <select
                                                                class="form-select1 <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="state" aria-describedby="stateHelp"
                                                                name="state">
                                                            </select>
                                                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="stateHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>


                                                    

                                                    

                                                    <div class="col-md- col-md-4">
                                                        <div class="mb-3">
                                                            <label for="city" class="form-label">City<span
                                                                    class="required"> *</span></label>
                                                            <select
                                                                class="form-select1 <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="city" aria-describedby="cityHelp"
                                                                name="city">
                                                            </select>
                                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="cityHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-12 col-md-12">
                                                        <div class="mb-3">
                                                            <label for="address" class="form-label">Address<span
                                                                    class="required"> *</span></label>
                                                            <textarea class="form-select1 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" aria-describedby="addressHelp"
                                                                name="address" rows="3"></textarea>

                                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="addressHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-6 col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="pinCode" class="form-label">Pincode<span
                                                                    class="required"> *</span></label>
                                                            <input type="text"
                                                                class="form-select1 <?php $__errorArgs = ['pinCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="pinCode" aria-describedby="pinCodeHelp"
                                                                name="pinCode">
                                                            <?php $__errorArgs = ['pinCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="pinCodeHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-6 col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="purchaseInvoice" class="form-label">Purchase
                                                                Invoice<span class="required"> *</span></label>
                                                            <input type="file"
                                                                class="form-select1 <?php $__errorArgs = ['purchaseInvoice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="purchaseInvoice"
                                                                aria-describedby="purchaseInvoiceHelp"
                                                                name="purchaseInvoice[]">
                                                                <small style="color: #7F2D91">Supported file format: jpg, jpeg, png,
                                                                    pdf</small>
                                                            <?php $__errorArgs = ['purchaseInvoice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text"
                                                                    id="purchaseInvoiceHelp" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="col-md-12 col-md-12">
                                                        <div class="mb-3">
                                                            <label for="issue" class="form-label">Describe your
                                                                Issue<span class="required"> *</span></label>
                                                            <textarea type="text" class="form-select1 <?php $__errorArgs = ['issue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="issue"
                                                                aria-describedby="issueHelp" name="issue"></textarea>
                                                            <?php $__errorArgs = ['issue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback form-text" id="issueHelp"
                                                                    role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 text-center mt-4">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>

                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-1 ">
                </div>
            </div>
        </div> <!-- End Content -->
    </div>
    <!-- End Content Wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $(document).ready(function() {
            $('#state').select2();
        });
    </script>

    <script>
        //Display Only Date till today //
        var dtToday = new Date();
        var month = dtToday.getMonth() + 1; // getMonth() is zero-based
        var day = dtToday.getDate();
        var year = dtToday.getFullYear();
        if (month < 10)
            month = '0' + month.toString();
        if (day < 10)
            day = '0' + day.toString();

        var maxDate = year + '-' + month + '-' + day;
        $('#dateID').attr('max', maxDate);
    </script>

    <script>
        $(document).ready(function() {
            /*------------------------------------------
            --------------------------------------------
            Country Dropdown Change Event
            --------------------------------------------
            --------------------------------------------*/
            $('#countries').on('change', function() {
                var idCountry = this.value;
                $("#state").html('');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-states')); ?>",
                    type: "POST",
                    data: {
                        country_id: idCountry,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(result) {
                        $('#state').html(
                            '<option value="">-- Select State --</option>');
                        $.each(result.states, function(key, value) {
                            $("#state").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                        $('#city').html('<option value="">-- Select City --</option>');
                    }
                });
            });
            /*------------------------------------------
            --------------------------------------------
            State Dropdown Change Event
            --------------------------------------------
            --------------------------------------------*/
            $('#state').on('change', function() {
                var idState = this.value;
                $("#city").html('');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-cities')); ?>",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(res) {
                        $('#city').html('<option value="">-- Select City --</option>');
                        $.each(res.cities, function(key, value) {
                            $("#city").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/user/complaintRegistration.blade.php ENDPATH**/ ?>