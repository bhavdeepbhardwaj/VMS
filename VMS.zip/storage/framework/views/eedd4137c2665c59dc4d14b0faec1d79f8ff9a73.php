<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('title.welcome'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .form-check-input:checked {
            background-color: #ffcc06;
            border-color: #ffcc06;
        }

        a {
            color: #ffcc06;
        }

        .btn.btn-primary {
            color: #fff;
            background-color: #ffcc06;
            border-color: #ffcc06;
        }

        .btn-primary1 {
            color: #ffcc06;
            background-color: #fff;
            border-color: #fff;
        }

        .btn-primary1:hover {
            color: #fff;
            background-color: #ffcc06;
            border-color: #fff;
        }

        .btn.btn-primary:hover {
            color: #ffcc06;
            background-color: #fff;
            border-color: #ffcc06;
        }

        .login-panel {
            color: #fff;
            background-color: #ffcc06;
            /* background: url('/assets/img/bg_welcome_background.jpg') 100% / cover no-repeat; */
            min-height: 600px;
            /* padding-top: 50px; */
        }

        .mt-2,
        .my-2 {
            margin-top: 40px !important;
        }

        .textColor {
            color: #662d91;
        }

        @media (max-width:767px) {
            .hidden-sm-down {
                display: none !important
            }
        }

        @media (min-width:768px) {
            .hidden-md-up {
                display: none !important
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTENT WRAPPER -->
    <!-- CONTENT WRAPPER -->
    <div class="container">

        <div class="row ">
            <div class="col-lg-6 col-xl-6 login-panel my-lg-9 pt-50">
                
                <h1 class="pl-3 pb-4 text-capitalize text-center pr-4">customer support</h1>

                <h3 class="pl-3 text-capitalize" style="padding-top: 21px;">Call Support</h3>
                <div class="pl-3 font-size-40"><i class="mdi mdi-cellphone-basic mdi-18px"></i> <a href="tel:+911204215944"
                        class=" text-white">+91 1204215944</a>&nbsp;&nbsp;<strong
                        style="border-left:2px solid #fff;"></strong>&nbsp;&nbsp;Mon - Sat : 10:00
                    AM To 06:00 PM</div>
                <h3 class="pl-3 pt-4 text-capitalize">Email Support</h3>
                <div class="pl-3 font-size-40"><i class="mdi mdi-email-outline mdi-18px"></i>
                    <a href="mailto:contact@globalsync.com.au"
                        class="text-white">contact@globalsync.com.au</a>&nbsp;&nbsp;<strong
                        style="border-left:2px solid #fff;"></strong>&nbsp;&nbsp;Dedicated
                    Support Team
                </div>
                

            </div>

            <div class="col-lg-1 col-xl-1 pt-25" style="padding-left: 80px!important;padding-top: 50px;">
                <div style="border-left:2px solid #ffcc06;height:665px" class="hidden-sm-down"></div>
            </div>

            <div class="col-lg-5 col-xl-5 my-lg-9">
                <?php if(auth()->guard()->check()): ?>
                    

                    <div class=" align-content-center justify-content-sm-center text-center pt-4">
                        <a href="/" title="GLOBALSYNC" class=" text-center">
                            <img class=" m-2" src="<?php echo e(asset('assets/img/logo/logo.png ')); ?>" style="padding-top: 120px"
                                alt="DEMO-INDIA" />
                        </a>
                    </div>
                    <h2 class=" my-2 text-center text-capitalize p-3" style="color:#ffcc06">Member Already Logged-In</h2>
                    <div class=" text-center m-1 font-size-16 pb-3" style="padding-top: 25px;">Back to redirect DEMO Member
                        Dashboard.</div>
                    <div class="align-content-center justify-content-sm-center text-center p-lg-9">

                        <?php if(Auth::user()->role == 1): ?>
                            <a href="<?php echo e(route('admin.home')); ?>" class="btn btn-primary">Admin Dashboard</a>
                        <?php elseif(Auth::user()->role == 2): ?>
                            <a href="<?php echo e(route('seller.home')); ?>" class="btn btn-primary">Sales Dashboard</a>
                        <?php elseif(Auth::user()->role == 0): ?>
                            <a href="<?php echo e(route('user.clinic')); ?>" class="btn btn-primary">Clinic
                                Dashboard</a>
                        <?php elseif(Auth::user()->role == 3): ?>
                            <a href="<?php echo e(route('demo.index')); ?>" class="btn btn-primary">Demo
                                Dashboard</a>
                        <?php endif; ?>

                    </div>
                <?php else: ?>
                    
                    <div class=" align-content-center justify-content-sm-center text-center pt-2">
                        <div class="text-center pb-1 pl-2" style="color:#ffcc06;padding-top: 50px;font-size: 35px;"></div>
                        <a href="/" title="GLOBALSYNC" class=" text-center">
                            <img class=" m-2" src="<?php echo e(asset('assets/img/logo/logo.png')); ?>" style="padding-top: 40px"
                                alt="GLOBALSYNC" />
                        </a>
                    </div>
                    <h2 class="text-center p-5" style="color:#ffcc06">Account Login</h2>
                    
                    <div class="align-content-center justify-content-sm-center text-center p-5">

                        <?php echo $__env->make('component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="row">
                                <div class="form-group col-md-12 mb-4">
                                    <input type="email" class="form-select1 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" autofocus
                                        placeholder="Email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-12 ">
                                    <input type="password" class="form-select1 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="current_password" name="password" autocomplete="current-password"
                                        placeholder="Password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="col-md-12">
                                    <div class="d-flex  justify-content-between">
                                        <div class="d-inline-block mr-3">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                                <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                            Remember me
                                        </div>

                                        <div class="form-check">
                                            <label class="form-check-label text-muted">
                                                <input type="checkbox" class="form-check-input" onclick="myFunction()"
                                                    id="current_password">
                                                Show Password
                                            </label>
                                        </div>
                                    </div>


                                </div>

                            </div>
                            <button type="submit" class="btn btn-primary m-2">Log In</button>
                            
                            <p class=" text-center pt-3">
                                <?php if(Route::has('password.request')): ?>
                                    <a class="text-blue text-center" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </p>
                        </form>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <!-- End Content Wrapper -->
    <!-- End CONTENT WRAPPER -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        function myFunction() {
            var x = document.getElementById("current_password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/welcome.blade.php ENDPATH**/ ?>