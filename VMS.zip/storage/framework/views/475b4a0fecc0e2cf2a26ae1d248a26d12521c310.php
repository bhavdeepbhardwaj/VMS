<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('title.admin_product'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- No Extra plugin used -->
    <link href="<?php echo e(asset('assets/plugins/data-tables/datatables.bootstrap5.min.css')); ?>" rel='stylesheet'>
    <link href="<?php echo e(asset('assets/plugins/data-tables/responsive.datatables.min.css')); ?>" rel='stylesheet'>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- CONTENT WRAPPER -->
    <div class="ec-content-wrapper">
        <div class="content">
            <div class="breadcrumb-wrapper d-flex align-items-center justify-content-between">
                <div>
                    <h1>Product</h1>
                    <p class="breadcrumbs"><span><a href="<?php echo e(route('admin.home')); ?>">Home</a></span>
                        <span><i class="mdi mdi-chevron-right"></i></span>Product
                    </p>
                </div>
                <div>
                    <a href="javascript:0" data-bs-toggle="modal" data-bs-target="#modal-contact"
                        class="view-detail btn btn-primary">Import / Export</i>
                    </a>
                    
                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary"> Add Product</a>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card card-default">
                        <div class="card-body">
                            <?php echo $__env->make('component.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="table-responsive">
                                <table id="responsive-data-table" class="table nowrap" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Product Type</th>
                                            <th>Product Series</th>
                                            <th>Product Model</th>
                                            <th>Product Number</th>
                                            <th>Product Configuration</th>
                                            <th>Serial Number</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $inforlooparr = [];
                                                $serialnumber = explode(',', $pro->serial_number);
                                            ?>
                                            <?php $__currentLoopData = $serialnumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($pro->type_name); ?></td>
                                                    <td><?php echo e($pro->name); ?></td>
                                                    <td><?php echo e($pro->model_number); ?></td>
                                                    <td><?php echo e($pro->product_number); ?></td>
                                                    <td><?php echo e($pro->titleName); ?></td>
                                                    <td>
                                                        <?php
                                                            $inforlooparr[] = explode(',', $pro->serial_number);
                                                        ?>
                                                        
                                                        
                                                        <?php echo e($data); ?>

                                                        

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Content -->
    </div>
    <!-- End Content Wrapper -->

    <!-- Contact Modal -->
    <div class="modal fade" id="modal-contact" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header justify-content-end border-bottom-0">
                    <button type="button" class="btn-close-icon" data-bs-dismiss="modal" aria-label="Close">
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>

                <div class="modal-body pt-0">
                    <div class="container">
                        <div class="row no-gutters">
                            <div class="col-md-12">
                                <form action="<?php echo e(route('importProducts')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group mb-4" style="max-width: 500px; margin: 0 auto;">
                                        <div class="custom-file text-left">
                                            <input type="file" name="file" class="custom-file-input" id="customFile">
                                            <label class="custom-file-label" for="customFile">Choose file</label>
                                        </div>
                                        <div class="col-md-12  pt-4">
                                            <a href="/assets/template/Sample Template For Product Listing.xlsx" download="Sample Template For Product Listing.xlsx" class="btn btn-primary" target="_blank">Sample Template For Listing</a>
                                            <button class="btn btn-primary">Import data</button>
                                            <a class="btn btn-primary" href="<?php echo e(route('export-products')); ?>">Export data</a>
                                        </div>
                                    </div>


                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Datatables -->
    <script src="<?php echo e(asset('assets/plugins/data-tables/jquery.datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/data-tables/datatables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/data-tables/datatables.responsive.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/admin/product/index.blade.php ENDPATH**/ ?>