<!-- LEFT MAIN SIDEBAR -->
<div class="ec-left-sidebar ec-bg-sidebar">
    <div id="sidebar" class="sidebar ec-sidebar-footer">

        <div class="ec-brand">
            <a href="/" title="Demo">
                <img class="ec-brand-name text-truncate" src="<?php echo e(asset('assets/img/logo/demo-logo.png ')); ?>"
                    alt="Demo" />
            </a>
        </div>

        <!-- begin sidebar scrollbar -->
        <div class="ec-navigation" data-simplebar>
            <!-- sidebar menu -->
            <ul class="nav sidebar-inner" id="sidebar-menu">
                <!-- Dashboard -->
                

                <!-- Visitor Registration -->
                <li class="">
                    <a class="sidenav-item-link" href="<?php echo e(route('demo.index')); ?>">
                        <i class="mdi mdi-account-card-details"></i>
                        <span class="nav-text">Visitor Registration</span>
                    </a>
                    <hr>
                </li>

            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/demo/layouts/component/sidebar.blade.php ENDPATH**/ ?>