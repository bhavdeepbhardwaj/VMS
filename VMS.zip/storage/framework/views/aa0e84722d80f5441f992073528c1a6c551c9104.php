<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="GLOBALSYNC">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- GOOGLE FONTS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600;700;800&family=Poppins:wght@300;400;500;600;700;800;900&family=Roboto:wght@400;500;700;900&display=swap"
        rel="stylesheet">

    <link href="https://cdn.materialdesignicons.com/4.4.95/css/materialdesignicons.min.css" rel="stylesheet" />

    <!-- PLUGINS CSS STYLE -->
    <link href="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.css ')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugins/simplebar/simplebar.css ')); ?>" rel="stylesheet" />

    <!-- globalsync CSS -->
    <link id="globalsync-css" href="<?php echo e(asset('assets/css/globalsync.css ')); ?>" rel="stylesheet" />

    <?php echo $__env->yieldContent('css'); ?>

    <!-- FAVICON -->
    <link href="<?php echo e(asset('assets/img/icons/favicon.ico  ')); ?>" rel="shortcut icon" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/img/icons/apple-touch-icon.png ')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/icons/favicon-32x32.png ')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/icons/favicon-16x16.png ')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/img/icons/site.webmanifest ')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('assets/img/icons/safari-pinned-tab.svg" color="#5bbad5 ')); ?>">


    <style>
        @media (max-width:767px) {
            .hidden-sm-down {
                display: none !important
            }
        }

        @media (min-width:768px) {
            .hidden-md-up {
                display: none !important
            }
        }
    </style>

</head>

<body class="ec-header-fixed ec-sidebar-fixed ec-sidebar-light ec-header-light" id="body">

    <!--  WRAPPER  -->
    <div class="wrapper">

        <!-- LEFT MAIN SIDEBAR -->
        <?php echo $__env->make('admin.layouts.component.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--  PAGE WRAPPER -->
        <div class="ec-page-wrapper">

            <!-- Header -->
            <?php echo $__env->make('admin.layouts.component.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- CONTENT WRAPPER -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- End Content Wrapper -->

            <!-- Footer -->
            <?php echo $__env->make('admin.layouts.component.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div> <!-- End Page Wrapper -->
    </div> <!-- End Wrapper -->

    <!-- Common Javascript -->
    <script src="<?php echo e(asset('assets/plugins/jquery/jquery-3.5.1.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/simplebar/simplebar.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/jquery-zoom/jquery.zoom.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/slick/slick.min.js ')); ?>"></script>

    <!-- Chart -->
    <script src="<?php echo e(asset('assets/plugins/charts/Chart.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/chart.js ')); ?>"></script>

    <!-- Google map chart -->
    <script src="<?php echo e(asset('assets/plugins/charts/google-map-loader.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/charts/google-map.js ')); ?>"></script>

    <!-- Date Range Picker -->
    <script src="<?php echo e(asset('assets/plugins/daterangepicker/moment.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.js ')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/date-range.js ')); ?>"></script>

    <!-- Option Switcher -->
    <script src="<?php echo e(asset('assets/plugins/options-sidebar/optionswitcher.js ')); ?>"></script>

    <!-- globalsync Custom -->
    <script src="<?php echo e(asset('assets/js/globalsync.js ')); ?>"></script>

    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\VMS\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>