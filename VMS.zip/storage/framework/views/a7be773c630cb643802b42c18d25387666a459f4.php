<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('title.admin_user'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- No Extra plugin used -->
    <link href="<?php echo e(asset('assets/plugins/data-tables/datatables.bootstrap5.min.css')); ?>" rel='stylesheet'>
    <link href="<?php echo e(asset('assets/plugins/data-tables/responsive.datatables.min.css')); ?>" rel='stylesheet'>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTENT WRAPPER -->
    <div class="ec-content-wrapper">
        <div class="content">
            <div class="breadcrumb-wrapper d-flex align-items-center justify-content-between">
                <div>
                    <h2>All Customers</h2>
                    <p class="breadcrumbs"><span><a href="<?php echo e(route('admin.home')); ?>">Home</a></span>
                        <span><i class="mdi mdi-chevron-right"></i></span>All Customers
                    </p>
                </div>
                <a href="<?php echo e(route('all-customers')); ?>" class="btn btn-primary">Export File</a>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card card-default">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="responsive-data-table" class="table nowrap" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Customer ID</th>
                                            <th>Customer Name</th>
                                            <th class="">Email</th>
                                            <th>Customer Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($user->id); ?></td>
                                                <td>
                                                    <a class="text-dark" href=""><?php echo e($user->name); ?></a>
                                                </td>
                                                <td class=""><?php echo e($user->email); ?></td>
                                                <td>
                                                    <?php if($user->role == 1): ?>
                                                        <span class="badge badge-success">Admin</span>
                                                    <?php elseif($user->role == 2): ?>
                                                        <span class="badge badge-info">Seller</span>
                                                    <?php elseif($user->role == 0): ?>
                                                        <span class="badge bg-primary">Customer</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Content -->
    </div>
    <!-- End Content Wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Datatables -->
    <script src="<?php echo e(asset('assets/plugins/data-tables/jquery.datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/data-tables/datatables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/data-tables/datatables.responsive.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/admin/user.blade.php ENDPATH**/ ?>