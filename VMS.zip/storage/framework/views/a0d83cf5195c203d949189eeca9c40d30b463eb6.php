<!-- Footer -->
<footer class="footer mt-auto">
    <div class="copyright bg-white">
        <p>
            Copyright &copy; <span id="ec-year"></span><a class="text-primary"
            href="/" target="_blank"> GLOBALSYNC Admin Dashboard</a>. All Rights Reserved.
          </p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\VMS\resources\views/admin/layouts/component/footer.blade.php ENDPATH**/ ?>