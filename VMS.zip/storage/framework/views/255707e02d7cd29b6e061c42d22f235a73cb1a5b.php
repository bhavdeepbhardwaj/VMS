<!-- Footer -->
<footer class="footer mt-auto">
    <div class="copyright bg-white">
        <p>
            Copyright &copy; <span id="ec-year"></span><a class="text-primary"
            href="/" target="_blank"> Demo Admin Dashboard</a>. All Rights Reserved.
          </p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/demo/layouts/component/footer.blade.php ENDPATH**/ ?>