<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>VMS LEAD</title>
</head>

<body>
    <p><strong>Admin Name :</strong> <?php echo e($users->admin_name); ?>,</p>
    <p><strong>Company Name :</strong> <?php echo e($users->company_name); ?>,</p>
    <p><strong>Email :</strong> <?php echo e($users->email); ?>,</p>
    <p><strong>Phone Number :</strong> <?php echo e($users->company_phone); ?>,</p>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\VMS\resources\views/emails/leads.blade.php ENDPATH**/ ?>