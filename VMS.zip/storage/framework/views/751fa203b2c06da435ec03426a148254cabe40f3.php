<!-- LEFT MAIN SIDEBAR -->
<div class="ec-left-sidebar ec-bg-sidebar">
    <div id="sidebar" class="sidebar ec-sidebar-footer">

        

        <div class="ec-brand">
            <a href="/" title="GLOBALSYNC">
                <img class="ec-brand-name text-truncate" src="<?php echo e(asset('assets/img/logo/dash-logo.png ')); ?>"
                    alt="GLOBALSYNC" />
            </a>
        </div>

        

        <!-- begin sidebar scrollbar -->
        <div class="ec-navigation" data-simplebar>
            <!-- sidebar menu -->
            <ul class="nav sidebar-inner" id="sidebar-menu">
                <!-- Dashboard -->
                <li class="">
                    <a class="sidenav-item-link" href="<?php echo e(route('admin.home')); ?>">
                        <i class="mdi mdi-view-dashboard-outline"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                    <hr>
                </li>

                <!-- Visitor Registration -->
                <li class="">
                    <a class="sidenav-item-link" href="<?php echo e(route('admin.visitor')); ?>">
                        <i class="mdi mdi-account-card-details"></i>
                        <span class="nav-text">Visitor Registration</span>
                    </a>
                    <hr>
                </li>

                <!-- Seller Sales Report -->
                

                <!-- Users -->
                

                <!-- Products -->
                

                <!-- Warranty Registration -->
                

                <!-- Warranty Extend -->
                

                <!-- Customers Complaint Registration -->
                

                <!-- Customers White Listed Cases Complaint -->
                

                <!-- Oneassist ADP Plan -->
                
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/admin/layouts/component/sidebar.blade.php ENDPATH**/ ?>