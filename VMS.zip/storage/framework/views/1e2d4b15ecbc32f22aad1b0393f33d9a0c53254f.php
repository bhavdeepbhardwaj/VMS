<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('title.demo_home'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- CONTENT WRAPPER -->
    <div class="ec-content-wrapper">
        <div class="content">
            <!-- Top Statistics -->
            <div class="row">
                <div class="col-xl-6 col-sm-6 p-b-15 lbl-card">
                    <div class="card card-mini dash-card card-1">
                        <div class="card-body">
                            <h2 class="mb-1"><?php echo e($users); ?></h2>
                            <p>Total Customers</p>
                            <span class="mdi mdi-account-group"></span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-sm-6 p-b-15 lbl-card">
                    <div class="card card-mini dash-card card-2">
                        <div class="card-body">
                            <h2 class="mb-1"><?php echo e($visitor); ?></h2>
                            <p>Total visitor Registration</p>
                            <span class=" mdi mdi-account-card-details"></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-xl-6 col-md-12 p-b-15">
                    <!-- Sales Graph -->
                    <div id="user-acquisition" class="card card-default">
                        <div class="card-header">
                            <h2>Visitor Registration</h2>
                        </div>
                        <div class="card-body">
                            
                            <canvas id="myAreaChartVisitor" style="height:350px;"></canvas>
                        </div>
                        <div class="card-footer small text-muted">Updated yesterday at <?php  echo date('F j, Y', time() ) ?></div>
                    </div>
                </div>

                <div class="col-xl-6 col-md-12 p-b-15">
                    <!-- Doughnut Chart -->
                    <div class="card card-default">
                        <div class="card-header justify-content-center">
                            <h2>Customers Overview</h2>
                        </div>
                        <div class="card-body">
                            <div id="piechart" style="height:350px;"></div>
                        </div>
                        <div class="card-footer small text-muted">Updated yesterday at <?php  echo date('F j, Y', time() ) ?></div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End Content -->
    </div>
    <!-- End Content Wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('assets/js/chart-dashboard.js ')); ?>"></script>

    

    <script src="<?php echo e(asset('assets/js/create-charts.js ')); ?>"></script>

    

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            var data = google.visualization.arrayToDataTable([
                ['Month Name', 'Registered User Count'],

                <?php
                    $user = \App\Models\User::select(DB::raw('COUNT(*) as count'), DB::raw('MONTHNAME(created_at) as month_name'))
                        ->whereYear('created_at', date('Y'))
                        ->groupBy('month_name')
                        ->orderBy('count')
                        ->get();

                    foreach ($user as $d) {
                        echo "['" . $d->month_name . "', " . $d->count . '],';
                    }
                ?>
            ]);

            var options = {
                // title: 'Users Detail',
                is3D: true,
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));

            chart.draw(data, options);
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('demo.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/demo/home.blade.php ENDPATH**/ ?>