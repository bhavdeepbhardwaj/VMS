<!-- LEFT MAIN SIDEBAR -->
<div class="ec-left-sidebar ec-bg-sidebar">
    <div id="sidebar" class="sidebar ec-sidebar-footer">

        

        <div class="ec-brand">
            <a href="/" title="<?php echo e(Auth::user()->company_name); ?>">
                <?php if(Auth::user()->company_logo != ''): ?>
                    <?php $__currentLoopData = explode(',', Auth::user()->company_logo); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="ec-brand-name text-truncate" src="<?php echo e('/' . $ref); ?>" alt="<?php echo e($ref); ?>" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <img class="ec-brand-name text-truncate" src="<?php echo e(asset('assets/img/logo/demo.png ')); ?>"
                        alt="<?php echo e(Auth::user()->company_name); ?>" />
                <?php endif; ?>
            </a>
        </div>

        <!-- begin sidebar scrollbar -->
        <div class="ec-navigation" data-simplebar>
            <!-- sidebar menu -->
            <ul class="nav sidebar-inner" id="sidebar-menu">
                <!-- Dashboard -->
                

                

                <!-- Clinic Registration -->
                <li class="">
                    <a class="sidenav-item-link" href="<?php echo e(route('user.list')); ?>">
                        <i class="mdi mdi-account-card-details"></i>
                        <span class="nav-text">Visitor Registration</span>
                    </a>
                    <hr>
                </li>

                 <li class="">
                    <a class="sidenav-item-link" href="<?php echo e(route('user.qrcode')); ?>">
                        <i class="mdi mdi-account"></i>
                        <span class="nav-text">QR Code</span>
                    </a>
                </li>


                

                <!-- Products -->
                

                <!-- warranty registration -->
                

                <!-- warranty Extend -->
                

                <!-- warranty registration -->
                

                <!-- Contact US -->
                

                

                <!-- Products -->
                

                <!-- Category -->
                

                <!-- Vendors -->
                

                <!-- Users -->
                

                <!-- Orders -->
                

                <!-- Reviews -->
                

                <!-- Brands -->
                

                <!-- Authentication -->
                

                <!-- Icons -->
                

                <!-- Other Pages -->
                
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\VMS\resources\views/user/layouts/component/sidebar.blade.php ENDPATH**/ ?>