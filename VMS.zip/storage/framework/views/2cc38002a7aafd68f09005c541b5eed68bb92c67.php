<?php if(session('success')): ?>
    <div class="alert alert-success">
        <i class="mdi mdi-check-circle-outline"></i> <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('usersuccess')): ?>
    <div class="alert alert-success">
        <i class="mdi mdi-check-circle-outline"></i> <?php echo e(session('usersuccess')); ?>

    </div>
<?php endif; ?>

<?php if(session('changePassword')): ?>
    <div class="alert alert-success">
        <i class="mdi mdi-check-circle-outline"></i> <?php echo e(session('changePassword')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <i class="mdi mdi-information-outline"></i> <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(session('status')): ?>
    <div class="alert alert-success">
        <i class="mdi mdi-check-circle-outline"></i> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger ">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
                <li class="mdi mdi-information-outline "> <?php echo e($error); ?></li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php if(session('msg')): ?>
    <div class="alert alert-success" role="alert">
        <i class="mdi mdi-alert-circle-outline"></i> <?php echo e(session('msg')); ?>

    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-danger" role="alert">
        <i class="mdi mdi-alert-circle-outline"></i> <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\VMS\resources\views/component/alert.blade.php ENDPATH**/ ?>