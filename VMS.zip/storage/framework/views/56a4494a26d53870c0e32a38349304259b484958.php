<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('title.list'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- No Extra plugin used -->
    <link href="<?php echo e(asset('assets/plugins/data-tables/datatables.bootstrap5.min.css')); ?>" rel='stylesheet'>
    <link href="<?php echo e(asset('assets/plugins/data-tables/responsive.datatables.min.css')); ?>" rel='stylesheet'>

    <style>
        .logo {
            position: absolute;
            width: 500px !important;
            /* padding: 20px 50px 0px 60px; */
            padding-right: 250px;
            padding-left: 50px;
        }

        .name-company {
            position: absolute;
            /* padding: 510px 50px 0px 110px; */
            padding: 350px 50px 0px 80px;
            font-size: 50px;
            line-height: 1;
            color: black;
            text-shadow: 0 0 black;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- CONTENT WRAPPER -->
    <div class="ec-content-wrapper">
        <div class="content">
            <div class="breadcrumb-wrapper d-flex align-items-center justify-content-between">
                <div>
                    <h2>Visitor Registration</h2>
                    <p class="breadcrumbs"><span><a href="<?php echo e(route('admin.home')); ?>">Home</a></span>
                        <span><i class="mdi mdi-chevron-right"></i></span>Visitor Registration
                    </p>
                </div>
                <div class=" float-right">
                    <button class="btn btn-primary profile-button" type="submit" onclick="generatePDF();">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-file-download"
                            width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                            fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <path d="M14 3v4a1 1 0 0 0 1 1h4"></path>
                            <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z">
                            </path>
                            <path d="M12 17v-6"></path>
                            <path d="M9.5 14.5l2.5 2.5l2.5 -2.5">
                            </path>
                        </svg>
                        Download
                        PDF</button>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card card-default">
                        <div class="card-body" id="converttoPDF">
                            <div class="row">
                                <img src="<?php echo e(asset('assets/img/qrCode/Landscape.png')); ?>" class="w-100" />
                                <img src="<?php echo e(asset('assets/img/logo/demo.png')); ?>" class="logo" />
                                <h2 class="name-company"><?php echo e(Auth::user()->company_name); ?></h2>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Content -->
    </div>
    <!-- End Content Wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Datatables -->
    <script src="<?php echo e(asset('assets/plugins/data-tables/jquery.datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/data-tables/datatables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/data-tables/datatables.responsive.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/js/html2pdf.js ')); ?>"></script>

    <script>
        function generatePDF() {
            var doc_name = "QR-Code.pdf";
            var element = document.getElementById('converttoPDF');
            html2pdf().set({
                html2canvas: {
                    scale: 4,
                    scrollY: 0
                }
            }).from(element).save(doc_name);
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VMS\resources\views/user/qrcode.blade.php ENDPATH**/ ?>