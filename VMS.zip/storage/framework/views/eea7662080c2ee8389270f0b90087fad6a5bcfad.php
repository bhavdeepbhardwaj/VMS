<!-- LEFT MAIN SIDEBAR -->
<div class="ec-left-sidebar ec-bg-sidebar">
    <div id="sidebar" class="sidebar ec-sidebar-footer">

        

        <div class="ec-brand">
            <a href="/" title="GLOBALSYNC">
                <img class="ec-brand-name text-truncate" src="<?php echo e(asset('assets/img/logo/clinic/logo.png ')); ?>"
                    alt="GLOBALSYNC" />
            </a>
        </div>

        <!-- begin sidebar scrollbar -->
        <div class="ec-navigation" data-simplebar>
            <!-- sidebar menu -->
            <ul class="nav sidebar-inner" id="sidebar-menu">
                <!-- Dashboard -->
                

                

                <!-- Clinic Registration -->
                <li class="">
                    <a class="sidenav-item-link" href="<?php echo e(route('user.clinic')); ?>">
                        <i class="mdi mdi-account-card-details"></i>
                        <span class="nav-text">clinic Registration</span>
                    </a>
                    <hr>
                </li>

                


                

                <!-- Products -->
                

                <!-- warranty registration -->
                

                <!-- warranty Extend -->
                

                <!-- warranty registration -->
                

                <!-- Contact US -->
                

                

                <!-- Products -->
                

                <!-- Category -->
                

                <!-- Vendors -->
                

                <!-- Users -->
                

                <!-- Orders -->
                

                <!-- Reviews -->
                

                <!-- Brands -->
                

                <!-- Authentication -->
                

                <!-- Icons -->
                

                <!-- Other Pages -->
                
            </ul>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\Globalsync-CMS\resources\views/user/layouts/component/sidebar.blade.php ENDPATH**/ ?>