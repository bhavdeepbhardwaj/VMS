<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Host Notification</title>
</head>

<body>
    <p><strong>Name :</strong> <?php echo e($vname); ?>,</p>
    <p><strong>Host :</strong> <?php echo e($vhost); ?>,</p>
    <p><strong>Purpose :</strong> <?php echo e($vpurpose); ?>,</p>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\VMS\resources\views/emails/hostnotification.blade.php ENDPATH**/ ?>