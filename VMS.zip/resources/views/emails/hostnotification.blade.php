<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Host Notification</title>
</head>

<body>
    <p>Dear Admin,</p>
    <p>New Visitior Arrived, below are the details:</p>
    <p><strong>Name :</strong> {{ $vname }},</p>
    <p><strong>Host :</strong> {{ $vhost }},</p>
    <p><strong>Purpose :</strong> {{ $vpurpose }},</p>
</body>

</html>
