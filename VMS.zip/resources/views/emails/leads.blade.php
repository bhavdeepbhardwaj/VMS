<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>VMS LEAD</title>
</head>

<body>
    <p><strong>Admin Name :</strong> {{ $users->admin_name }},</p>
    <p><strong>Company Name :</strong> {{ $users->company_name }},</p>
    <p><strong>Email :</strong> {{ $users->email }},</p>
    <p><strong>Phone Number :</strong> {{ $users->company_phone }},</p>
</body>

</html>
