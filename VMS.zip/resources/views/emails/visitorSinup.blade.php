<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>GLOBALSYNC</title>
    <link rel="stylesheet" href="css/foundation-emails.css" />
    {{-- <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet"> --}}


</head>

<body>
    <img src="https://globalsync.com.au/wp-content/uploads/2022/12/header.gif" alt="GLOBALSYNC" style="" width="auto">

    <p><strong>Dear {{ $users->admin_name }},</strong></p>
    {{-- <p><strong>Dear ,</strong></p> --}}

    <p>Thank you for choosing our Visitor Management System to
        manage visitors at the same time keeping your workplace safe
        and secure.</p>

    <p>You will shortly receive the detail from us to access the VMS
        for your organisation.</p>

    <p>Also, one of our executive will connect with you soon with
        all details.</p>

    <p>For any query or information, OR Email us at <a href="mailto:sales@globalsync.com.au">sales@globalsync.com.au</a></p>

        <p style="padding-left: 500px; font-size: 20px;"><strong>Follow us on social media:</strong></p>
        <div style="padding-left: 315px;!important">
            <ul style="list-style: none;  display: flex;">
                <li style="padding: 0px 10px;!important"><a href="https://www.linkedin.com/company/global-sync/" target="_blank"><img src="https://globalsync.com.au/wp-content/uploads/2022/12/LinkedIn.png" style="" width="140"></a></li>
                <li style="padding: 0px 10px;!important"><a href="https://www.facebook.com/GlobalSync1" target="_blank"><img src="https://globalsync.com.au/wp-content/uploads/2022/12/Facebook.png" style="" width="140"></a></li>
                <li style="padding: 0px 10px;!important"><a href="https://www.youtube.com/@globalsync" target="_blank"><img src="https://globalsync.com.au/wp-content/uploads/2022/12/YouTube.png" style="" width="140"></a></li>
            </ul>
        </div>
        <p style="padding-left: 570px;!important"><strong>It's Us</strong></p>

    <img src="https://globalsync.com.au/wp-content/uploads/2022/12/footer.gif" alt="GLOBALSYNC" style=""
        width="1200">


</body>

</html>
